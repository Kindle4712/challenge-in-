# 第三次挑战：Ray Serve 路由实验

提交编号：102503110。目录按指定的目标三结构整理；不包含 target1。目标三五个正式配置已核验，报告、作业感受和 AI 使用说明已整理。

## 环境

AutoDL 单机四张 NVIDIA GeForce RTX 4090（24 GB），Python 3.10，Ray 2.56.0，SGLang 0.5.14，Torch 2.11.0+cu130，protobuf 6.33.5。后端模型 Qwen/Qwen3-0.6B，TP=1，mem-fraction-static=0.65。版本来自实验对话记录，归档没有完整 pip freeze；请复现者检查实际依赖解析结果。

模型权重、Python 环境、安装包及缓存不包含在提交中。代码使用实验服务器的绝对根目录 `/root/autodl-tmp/hw3`。四个逻辑 worker 共用同一主机网络，127.0.0.1 后端访问仅适用于这个单机拓扑。

## 安装与准备

在支持相应 CUDA/PyTorch 的四 GPU Linux 环境创建 Python 3.10 环境，将本包的 src 内容复制到 `/root/autodl-tmp/hw3/src`。将模型权重另行下载至 `/root/autodl-tmp/hw3/models/Qwen3-0.6B`。

```bash
python -m pip install 'sglang==0.5.14' 'ray[serve]==2.56.0' 'protobuf==6.33.5' httpx
python -m pip install -r /root/autodl-tmp/hw3/src/workload/requirements.txt
ulimit -n 65535
export RAY_SERVE_QUEUE_LENGTH_RESPONSE_DEADLINE_S=2
mkdir -p /root/autodl-tmp/hw3/logs
```

不建议将此精简安装列表理解为跨 CUDA/驱动平台的完整 lockfile。实验实际 Torch 版本列于上方。SGLang 与 Ray 2.56 的扩展接口及私有队列探测接口存在版本耦合，换版本需重新验证。

## 后端与集群

```bash
bash /root/autodl-tmp/hw3/src/start_backends.sh
nohup python -u /root/autodl-tmp/hw3/src/start_cluster.py > /root/autodl-tmp/hw3/logs/ray-cluster-new.log 2>&1 < /dev/null &
```

等四个 SGLang 日志均显示服务就绪，且集群日志出现“1 个 head + 4 个 worker”。start_cluster.py 会重写 cluster.json；归档的 results/target3/evidence/cluster_snapshot.json 只是证据快照，不应作为新集群地址使用。不得同时启动多个集群脚本。

## 各轮部署与回放

每轮先停止旧 Serve，再启动对应 deployment，等就绪、清缓存后回放。全部使用同一 HTTP 入口和固定 workload。run_workload.py 的 router-name 只记录标签，实际路由以 deployment 为准。

```bash
python - <<'PY'
import json, ray
from ray import serve
with open('/root/autodl-tmp/hw3/cluster.json') as f:
    address = json.load(f)['address']
ray.init(address=address, namespace='serve')
serve.shutdown()
ray.shutdown()
PY
```

选择部署文件 deploy_a.py、deploy_b10.py、deploy_b20.py、deploy_c.py 或 deploy_d.py，例如：

```bash
nohup python -u /root/autodl-tmp/hw3/src/deploy_d.py > /root/autodl-tmp/hw3/logs/serve-d-new.log 2>&1 < /dev/null &
```

确认部署就绪；D 应出现 `D router v3 active` 和四副本哈希环。再执行一轮（最后参数是新目录名称，不得使用已有结果目录）：

```bash
bash /root/autodl-tmp/hw3/src/replay_round.sh affinity_fallback 20 D_new_round
```

参数配对：A 为 p2c/5，B10 为 p2c/10，B20 为 p2c/20，C 为 consistent_hash/20，D 为 affinity_fallback/20。脚本前台运行至结束；非零退出需检查日志和 summary，不应覆盖失败结果。

回放结果统一写入 `/root/autodl-tmp/hw3/results/target3/<NEW_RUN_NAME>`，上述示例为 `results/target3/D_new_round`。新轮次单独保存；下表中的历史结果目录保留原样，不自动替换为新结果。

客户端测试使用 Python 自带的 unittest，不需要 pytest。安装 workload/requirements.txt 中的 aiohttp 后，在 src/workload 目录运行：

```bash
python -m unittest discover -s tests -v
```

本地仅完成源码编译检查，当前本地环境缺少 aiohttp，未执行客户端测试；GPU 推理和 Ray 路由复现需在上述服务器环境运行。

## 代码用途

- start_cluster.py：创建 head 和四个 worker，检查五节点活跃，持续保持集群。
- deploy_a.py / deploy_b10.py / deploy_b20.py：四副本默认 P2C，分别设并发上限 5/10/20。
- deploy_c.py：纯一致性哈希亲和，不启用 fallback。
- deploy_d.py 与 affinity_router.py：当前 D 第三版，探测合并间隔 100 ms，主副本负载门槛 16，负载差门槛 8。
- docs/history/affinity_router_run2.py：第二版 D 历史代码，非正式选定版本。初版 D 源码未单独保存，不能从当前代码重现其历史结果。
- start_backends.sh / replay_round.sh：为归档后新增的复现辅助脚本，未在原 GPU 服务器重新运行；不改变历史实验结果。
- workload/：课程固定负载、回放、校验和比较脚本。

## 原始结果与报告对应

结果根目录为 results/target3。

| 报告配置 | 结果目录 | 原始 run_name |
|---|---|---|
| A | A_default/run-3 | A_default_run3 |
| B10 | B_candidates/10/run-1 | B10_run1 |
| B20 | B_candidates/20/run-1 | B20_run1 |
| C | C_affinity/run-1 | C_affinity_run1 |
| D | D_improved/run-3 | D_affinity_fallback_run3 |

A_default/run-1、run-2 是失败轮次；D_improved/run-1 是未观察到分流的诊断轮次，run-2 有一个 ReadError 失败。不混入主表；各轮 config.json 保留原服务器路径以保持原始记录。

results/target3/evidence/核验结果.json 记录本地从 CSV 重算的拓扑分布及完整性检查；results/target3/evidence/comparison.json 由课程 compare_runs.py 生成，源文件路径相对于提交包根目录。以下命令须在 HW3-102503110 根目录运行：

```bash
python src/workload/compare_runs.py --baseline A \
  --run A=results/target3/A_default/run-3/summary.json \
  --run B10=results/target3/B_candidates/10/run-1/summary.json \
  --run B20=results/target3/B_candidates/20/run-1/summary.json \
  --run C=results/target3/C_affinity/run-1/summary.json \
  --run D=results/target3/D_improved/run-3/summary.json \
  --output results/target3/evidence/comparison.json
```

results/target3/evidence/logs 保留所有原始日志；report.pdf 与 AI使用说明情况（第三次挑战）.pdf 已更新，其可编辑内容在 src/docs。

## 材料说明

本包按指定目录整理目标三。作业感受和 AI 使用说明参考前两次挑战的表达方式，并依据本次对话、操作和原始数据撰写；其中个人认识请本人核对。文档明确披露了 AI 对代码、实验分析和文字整理的辅助。
