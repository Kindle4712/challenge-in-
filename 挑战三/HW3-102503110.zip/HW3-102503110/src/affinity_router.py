import asyncio
import logging
import time

from ray.serve.experimental.consistent_hash_router import ConsistentHashRouter

logger = logging.getLogger("ray.serve")


class AffinityFallbackRouter(ConsistentHashRouter):
    def initialize_state(self, **kwargs):
        super().initialize_state(**kwargs)
        self._load_snapshot = {}
        self._last_probe = float("-inf")
        self._probe_lock = asyncio.Lock()
        self.fallback_decisions = 0
        logger.info(
            "D router v3 active: probe_interval=0.1s threshold=16 load_gap=8"
        )

    async def _get_loads(self, replicas):
        async with self._probe_lock:
            if time.monotonic() - self._last_probe >= 0.1:
                self._load_snapshot = {
                    r.replica_id: q
                    for r, q in await self._probe_queue_lens(replicas, 0)
                    if q is not None
                }
                self._last_probe = time.monotonic()
            return dict(self._load_snapshot)

    async def choose_replicas(self, candidate_replicas, pending_request=None):
        if not candidate_replicas:
            return []
        if pending_request is None:
            return [candidate_replicas]

        pending_request.routing_context.should_backoff = True
        key = self._routing_key(pending_request)
        if key is None:
            return [candidate_replicas]

        ranked = self._lookup_ranked_replicas(key)
        if not ranked:
            return [candidate_replicas]

        primary = self._replicas.get(ranked[0])
        others = [
            r for r in candidate_replicas if r.replica_id != ranked[0]
        ]
        if primary is None:
            return [others] if others else []

        loads = await self._get_loads(candidate_replicas)
        primary_load = loads.get(primary.replica_id)
        available = [
            r for r in others
            if r.replica_id in loads
            and loads[r.replica_id] < r.max_ongoing_requests
        ]

        if primary_load is not None and available:
            lowest = min(loads[r.replica_id] for r in available)
            if primary_load >= 16 and primary_load - lowest >= 8:
                self.fallback_decisions += 1
                if self.fallback_decisions == 1 or self.fallback_decisions % 100 == 0:
                    logger.info(
                        "D fallback decision=%s primary_load=%s lowest_load=%s",
                        self.fallback_decisions, primary_load, lowest,
                    )
                return [available, [primary]]

        return [[primary], others] if others else [[primary]]
