import asyncio
import json
import time
from pathlib import Path

import httpx
import ray
from ray import serve
from starlette.requests import Request
from starlette.responses import StreamingResponse, JSONResponse

root = Path("/root/autodl-tmp/hw3")
address = json.loads((root / "cluster.json").read_text())["address"]
ray.init(address=address)

@serve.deployment(
    num_replicas=4,
    max_ongoing_requests=10,
    max_replicas_per_node=1,
    ray_actor_options={"num_cpus": 1, "num_gpus": 0},
)
class SGLangProxy:
    def __init__(self):
        self.node_id = ray.get_runtime_context().get_node_id()
        node = next(
            n for n in ray.nodes() if n["NodeID"] == self.node_id
        )
        workers = [
            i for i in range(4)
            if node["Resources"].get(f"worker_{i}", 0) > 0
        ]
        assert len(workers) == 1, "Replica 未部署在指定 worker 上"

        self.worker = workers[0]
        self.backend = f"http://127.0.0.1:{30000 + self.worker}"
        self.replica_id = str(serve.get_replica_context().replica_id)
        self.client = httpx.AsyncClient(
            timeout=None,
            trust_env=False,
            limits=httpx.Limits(
                max_connections=256,
                max_keepalive_connections=64,
            ),
        )
        print(
            f"Replica={self.replica_id} Node={self.node_id} "
            f"Backend={self.backend}",
            flush=True,
        )

    async def __call__(self, request: Request):
        if request.method != "POST" or request.url.path != "/generate":
            return JSONResponse({"error": "Use POST /generate"}, status_code=404)

        headers = {"Content-Type": "application/json"}
        for name in (
            "X-Session-Id",
            "X-Workload-Request-ID",
            "X-Prefix-Family",
        ):
            value = request.headers.get(name)
            if value is not None:
                headers[name] = value

        upstream_request = self.client.build_request(
            "POST",
            self.backend + "/generate",
            content=await request.body(),
            headers=headers,
        )
        upstream = await self.client.send(upstream_request, stream=True)

        async def stream():
            try:
                async for chunk in upstream.aiter_raw():
                    yield chunk
            finally:
                await upstream.aclose()

        response_headers = {
            "X-Ray-Replica-ID": self.replica_id,
            "X-Ray-Node-ID": self.node_id,
            "X-SGLang-Backend": self.backend,
            "Content-Type": upstream.headers.get(
                "content-type", "text/event-stream"
            ),
        }
        return StreamingResponse(
            stream(),
            status_code=upstream.status_code,
            headers=response_headers,
        )

serve.start(
    proxy_location="HeadOnly",
    http_options={"host": "127.0.0.1", "port": 8000},
)
serve.run(SGLangProxy.bind(), name="routing", route_prefix="/")
print("B10 组部署就绪：4 Replica，max_ongoing_requests=10", flush=True)

while True:
    time.sleep(10)
