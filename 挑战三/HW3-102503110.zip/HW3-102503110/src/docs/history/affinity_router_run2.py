import logging

from ray.serve.experimental.consistent_hash_router import ConsistentHashRouter

logger = logging.getLogger("ray.serve")


class AffinityFallbackRouter(ConsistentHashRouter):
    def initialize_state(self, **kwargs):
        super().initialize_state(**kwargs)
        self.fallback_decisions = 0
        logger.info(
            "D AffinityFallbackRouter active: threshold=10, load_gap=4"
        )

    async def choose_replicas(self, candidate_replicas, pending_request=None):
        if not candidate_replicas:
            return []

        if pending_request is not None:
            pending_request.routing_context.should_backoff = True

        key = self._routing_key(pending_request)
        if key is None:
            return [candidate_replicas]

        ranked = self._lookup_ranked_replicas(key)
        if not ranked:
            return [candidate_replicas]

        primary = self._replicas.get(ranked[0])
        others = [
            r for r in candidate_replicas
            if r.replica_id != ranked[0]
        ]
        if primary is None:
            return [others] if others else []

        # Probe current Serve replica load; never inspect future requests.
        loads = {
            r.replica_id: q
            for r, q in await self._probe_queue_lens(candidate_replicas, 0)
            if q is not None
        }
        primary_load = loads.get(primary.replica_id)
        available = [
            r for r in others
            if r.replica_id in loads
            and loads[r.replica_id] < r.max_ongoing_requests
        ]

        if primary_load is not None and available:
            lowest = min(loads[r.replica_id] for r in available)
            if primary_load >= 10 and primary_load - lowest >= 4:
                self.fallback_decisions += 1
                if self.fallback_decisions == 1 or self.fallback_decisions % 100 == 0:
                    logger.info(
                        "D fallback decision=%s primary_load=%s lowest_load=%s",
                        self.fallback_decisions, primary_load, lowest,
                    )
                return [available, [primary]]

        return [[primary], others] if others else [[primary]]
