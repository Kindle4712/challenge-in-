#!/usr/bin/env bash
set -euo pipefail
if [[ $# -ne 3 ]]; then
  echo 'Usage: bash replay_round.sh ROUTER MAX_ONGOING NEW_RUN_NAME' >&2
  exit 2
fi
router=$1
ongoing=$2
run_name=$3
if [[ ! "$run_name" =~ ^[a-zA-Z0-9_-]+$ || ! "$ongoing" =~ ^[1-9][0-9]*$ ]]; then
  echo 'Invalid run name or concurrency' >&2
  exit 2
fi
root=/root/autodl-tmp/hw3
output_dir="$root/results/target3/$run_name"
cd "$root/src/workload"
if [[ -e "$output_dir" ]]; then
  echo "Result path exists: $output_dir" >&2
  exit 2
fi
python validate_workload.py mooncake_prefix_workload_v2_seed2026.jsonl
for port in 30000 30001 30002 30003; do
  echo "flush $port"
  curl --fail --max-time 30 -sS -X POST "http://127.0.0.1:$port/flush_cache"
  echo
done
python -u run_workload.py \
  --policy serve --run-name "$run_name" --router-name "$router" \
  --max-ongoing-requests "$ongoing" \
  --base-url http://127.0.0.1:8000 \
  --workload mooncake_prefix_workload_v2_seed2026.jsonl \
  --max-in-flight 2048 --output-dir "$output_dir"
