#!/usr/bin/env bash
set -euo pipefail
root=/root/autodl-tmp/hw3
mkdir -p "$root/logs"
for i in 0 1 2 3; do
  port=$((30000 + i))
  CUDA_VISIBLE_DEVICES="$i" nohup python -m sglang.launch_server \
    --model-path "$root/models/Qwen3-0.6B" \
    --host 127.0.0.1 --port "$port" --tp-size 1 \
    --mem-fraction-static 0.65 \
    > "$root/logs/sglang-$i-new.log" 2>&1 < /dev/null &
  echo "backend=$i port=$port pid=$!"
done
