import json
import time
from pathlib import Path

import ray
from ray.cluster_utils import Cluster

root = Path("/root/autodl-tmp/hw3")
cluster = Cluster()

try:
    cluster.add_node(
        num_cpus=0,
        num_gpus=0,
        include_dashboard=False,
        object_store_memory=128 * 1024 * 1024,
    )

    for i in range(4):
        cluster.add_node(
            num_cpus=4,
            num_gpus=0,
            resources={f"worker_{i}": 1},
            object_store_memory=128 * 1024 * 1024,
        )

    cluster.wait_for_nodes()
    ray.init(address=cluster.address)

    nodes = [node for node in ray.nodes() if node["Alive"]]
    assert len(nodes) == 5, f"活跃节点数量异常：{len(nodes)}"

    info = {
        "address": cluster.address,
        "nodes": [
            {
                "node_id": node["NodeID"],
                "resources": node["Resources"],
            }
            for node in nodes
        ],
    }
    (root / "cluster.json").write_text(
        json.dumps(info, indent=2), encoding="utf-8"
    )

    print("集群就绪：1 个 head + 4 个 worker", flush=True)
    print(json.dumps(info, indent=2), flush=True)

    while True:
        time.sleep(10)
finally:
    ray.shutdown()
    cluster.shutdown()
